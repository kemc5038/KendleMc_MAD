package com.example.kemc5038.lab6;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void makeAStringPlease(View view) {
        //name value
        EditText name = findViewById(R.id.editText);
        String nameValue = name.getText().toString();

        //radio button value
        RadioGroup ready = findViewById(R.id.radioGroup);
        int readyType = ready.getCheckedRadioButtonId();
        String readyTypeText = "";

        //set text based on radio selection
        if(readyType == R.id.radioButton6){
            readyTypeText = "ready";
        }
        else if(readyType == R.id.radioButton5){
            readyTypeText = "partially ready";
        }
        else if(readyType == R.id.radioButton4){
            readyTypeText = "not ready";
        }

        //spinner value
        Spinner event = findViewById(R.id.spinner);
        String eventType = String.valueOf(event.getSelectedItem());

        //switch value
        Switch toggle = findViewById(R.id.switch1);
        boolean activated = toggle.isChecked();

        //textView value
        TextView finalText = findViewById(R.id.message);
        String punct;

        //if exaggerate is true add and exclamation mark
        if(activated){
            //text value = name + radio + spinner + !
            punct = "!";
        }
        else{
            punct = ".";
        }

        if(readyType == -1){
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a readiness level";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            finalText.setText(nameValue + " is " + readyTypeText + " for " + eventType + punct);
        }
    }
}