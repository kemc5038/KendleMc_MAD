package e.owner.moodring;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;


public class MainActivity extends Activity {
    //make a new mood class to hold user info
    private getMood myMood = new getMood();

    //launch main activity and wait for the submit button
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //on press call Mood to setup second activity
        Button button = findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                Mood(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    private void Mood(View view){
        //calculate mood with this views inputs
        Spinner one = findViewById(R.id.spinner);
        Spinner two = findViewById(R.id.spinner2);
        Spinner three = findViewById(R.id.spinner3);
        Spinner four = findViewById(R.id.spinner4);
        Spinner five= findViewById(R.id.spinner5);
        Spinner six = findViewById(R.id.spinner6);
        Integer oneScore = one.getSelectedItemPosition();
        Integer twoScore = two.getSelectedItemPosition();
        Integer threeScore = three.getSelectedItemPosition();
        Integer fourScore = four.getSelectedItemPosition();
        Integer fiveScore = five.getSelectedItemPosition();
        Integer sixScore = six.getSelectedItemPosition();
        Integer totalScore = oneScore + twoScore + threeScore + fourScore + fiveScore + sixScore;
        //call getMood
        myMood.setMood(totalScore);
        //get the values from getMood
        String newRinger = myMood.getRinger();
        String newColor = myMood.getColors();
        //start the new activity with displayMood
        Intent intent = new Intent(this, displayMood.class);
        intent.putExtra("thisRinger", newRinger);
        intent.putExtra("thisColor", newColor);
        startActivity(intent);
    }


}
