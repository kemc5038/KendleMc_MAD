package e.owner.moodring;


public class getMood {
    private String color;
    private String ringer;
    public void setMood(Integer moodValue) {
        //between 0 and 32
        if(moodValue <= 6){
            //black/grey 0 - 8
            color = "black";
            ringer = "bad";
        }
        else if(moodValue > 7 && moodValue <= 13){
            //blue/lightblue 9 - 16
            color = "blue";
            ringer = "notgreat";
        }
        else if(moodValue > 14 && moodValue <= 20){
            //pink/purple 17 - 25
            color = "purple";
            ringer = "fine";
        }
        else if(moodValue > 21 && moodValue <= 27){
            //green/yellow 26 - 34
            color = "green";
            ringer = "upbeat";
        }
        else if (moodValue > 27){
            //yellow/orange 35 - 38
            color = "yellow";
            ringer = "great";
        }
    }

    public String getRinger(){
        return ringer;
    }

    public String getColors(){
        return color;
    }
}
