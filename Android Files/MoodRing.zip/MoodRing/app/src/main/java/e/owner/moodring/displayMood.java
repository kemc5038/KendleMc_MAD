package e.owner.moodring;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class displayMood extends Activity {
    public String thisRinger;
    public String thisColor;
    public boolean soundClick = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_mood);

        Intent intent = getIntent();
        thisColor = intent.getStringExtra("thisColor");
        thisRinger = intent.getStringExtra("thisRinger");

        ImageView newBackground = findViewById(R.id.imageView2);
        int drawableId = getResources().getIdentifier(thisColor, "drawable", getPackageName());
        newBackground.setImageResource(drawableId);

        int soundId = getResources().getIdentifier(thisRinger, "raw", getPackageName());
        final MediaPlayer ringTone = MediaPlayer.create(this, soundId);
        ImageButton playRingtone = findViewById(R.id.imageButton);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                if(soundClick == false){
                    soundClick = true;
                    ringTone.start();
                }
                else {
                    soundClick = false;
                    ringTone.stop();
                }
            }
        };
        playRingtone.setOnClickListener(onclick);
    }
}
