package com.example.owner.lab7;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends Activity {

    private PizzaShop myPizzaShop = new PizzaShop();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findPizza(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    private void findPizza(View view){
        Spinner priceSpinner = findViewById(R.id.spinner);
        Integer priceSelect = priceSpinner.getSelectedItemPosition();
        myPizzaShop.setPizzaShop(priceSelect);
        String suggested = myPizzaShop.getPizzaShop();
        String suggestedURL = myPizzaShop.getPizzaShopURL();

        Intent intent = new Intent(this, RecievePizza.class);
        intent.putExtra("pizzaShopName", suggested);
        intent.putExtra("pizzaShopURL", suggestedURL);
        startActivity(intent);
    }
}
