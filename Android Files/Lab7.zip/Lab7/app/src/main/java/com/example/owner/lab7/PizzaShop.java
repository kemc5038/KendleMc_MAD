package com.example.owner.lab7;

public class PizzaShop {
    private String pizzaShop;
    private String pizzaShopURL;
    private void setPizzaInfo(Integer pizzaPrice){
        switch (pizzaPrice){
            case 0: //$
                pizzaShop="Cosmo's";
                pizzaShopURL="http://cosmospizza.com/";
                break;
            case 1: //$$
                pizzaShop="The Sink";
                pizzaShopURL="https://thesink.com/";
                break;
            case 2: //$$$
                pizzaShop="Basta";
                pizzaShopURL="https://www.bastaboulder.com/";
                break;
            case 3: //$$$$
                pizzaShop="Luca";
                pizzaShopURL="https://www.lucadenver.com/";
                break;
            default:
                pizzaShop="none";
                pizzaShopURL="https://www.google.com/search?q=denver+pizza&rlz=1C1CHBF_enUS761US761&oq=denver+pizza&aqs=chrome.0.69i59j0l5.3399j1j4&sourceid=chrome&ie=UTF-8";
        }
    }

    public void setPizzaShop(Integer price){

        setPizzaInfo(price);
    }

    public void setPizzaShopURL(Integer price){
        setPizzaInfo(price);
    }

    public String getPizzaShop(){
        return pizzaShop;
    }

    public String getPizzaShopURL(){
        return pizzaShopURL;
    }
}
