package mcdowell.kendle.madfinal;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class suggestPizza extends AppCompatActivity {

    private String pizzaShopName;
    private String pizzaShopURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggest_pizza);

        Intent intent = getIntent();
        pizzaShopName = intent.getStringExtra("pizzaShopName");
        pizzaShopURL = intent.getStringExtra("pizzaShopURL");

        TextView messageView = findViewById(R.id.textView2);
        messageView.setText("You should swing by " + pizzaShopName);

        Button webButton = findViewById(R.id.button3);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebsite(view);
            }
        };
        webButton.setOnClickListener(onclick);
    }

    private void loadWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(pizzaShopURL));
        startActivity(intent);
    }
}
