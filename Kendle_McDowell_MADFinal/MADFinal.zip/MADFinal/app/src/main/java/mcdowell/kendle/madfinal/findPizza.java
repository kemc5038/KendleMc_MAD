package mcdowell.kendle.madfinal;

public class findPizza {
    public String pizzaShop;
    public String pizzaShopURL;
    
    public void setPizzaJoint(Integer pizzaSelect) {
        switch (pizzaSelect) {
            case 0:
                pizzaShop = "Pizzaria Locale";
                pizzaShopURL = "https://localeboulder.com/";
                break;
            case 1: //$$
                pizzaShop = "Backcountry Pizza";
                pizzaShopURL = "https://backcountrypizzaandtaphouse.info/";
                break;
            case 2: //$$$
                pizzaShop = "Boss Lady";
                pizzaShopURL = "https://bossladypizza.com/";
                break;
            default:
                pizzaShop = "none";
                pizzaShopURL = "https://www.google.com/search?q=denver+pizza&rlz=1C1CHBF_enUS761US761&oq=denver+pizza&aqs=chrome.0.69i59j0l5.3399j1j4&sourceid=chrome&ie=UTF-8";
        }

    }

    public String getPizzaShop(){
        return pizzaShop;
    }

    public String getPizzaShopURL(){
        return pizzaShopURL;
    }
}