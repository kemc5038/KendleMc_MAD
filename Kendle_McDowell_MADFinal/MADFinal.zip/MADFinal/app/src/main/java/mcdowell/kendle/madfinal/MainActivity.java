package mcdowell.kendle.madfinal;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private findPizza myPizzaShop = new findPizza();
    public Integer pizzaSelect;
    public boolean pizzaWasMade = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                if(pizzaWasMade == false){
                    Context context = getApplicationContext();
                    CharSequence text = "Please make the pizza first!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                else {
                    pizzaWasMade = false;
                    findPizza(view);
                }
            }
        };
        button.setOnClickListener(onclick);
    }

    private void findPizza(View view){

        myPizzaShop.setPizzaJoint(pizzaSelect);
        String suggested = myPizzaShop.getPizzaShop();
        String suggestedURL = myPizzaShop.getPizzaShopURL();
        Intent intent = new Intent(this, suggestPizza.class);
        intent.putExtra("pizzaShopName", suggested);
        intent.putExtra("pizzaShopURL", suggestedURL);
        startActivity(intent);
    }

    public void displayPizza(View view) {
        ToggleButton toggle = findViewById(R.id.toggleButton);
        String sauce = toggle.getText().toString();
        CheckBox cheeseCheckBox = findViewById(R.id.checkBox);
        Boolean cheese = cheeseCheckBox.isChecked();
        CheckBox veggieCheckBox = findViewById(R.id.checkBox2);
        Boolean veggie = veggieCheckBox.isChecked();
        CheckBox supremeCheckBox = findViewById(R.id.checkBox3);
        Boolean supreme = supremeCheckBox.isChecked();
        CheckBox meatCheckBox = findViewById(R.id.checkBox4);
        Boolean meat = meatCheckBox.isChecked();

        if (cheese == false && meat == false && supreme == false && veggie == false) {
            Context context = getApplicationContext();
            CharSequence text = "Please select pizza toppings!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            pizzaWasMade = true;
            Spinner size = findViewById(R.id.spinner);
            String pizzaSize = String.valueOf(size.getSelectedItem());

            EditText name = findViewById(R.id.editText);
            String nameValue = name.getText().toString();

            TextView pizzaText = findViewById(R.id.textView);
            String first = "Your favorite is a ";
            String second = " pizza called ";
            String third = " and has ";
            String fourth = " sauce, which sounds delicious.";

            pizzaText.setText(first + pizzaSize + second + nameValue + third + sauce + fourth);
            ImageView userPizza = findViewById(R.id.imageView);
            if (cheese == true && meat == false && supreme == false && veggie == false) {
                userPizza.setImageResource(R.drawable.pizza_cheese);
                pizzaSelect = 0;
            }  else if (meat == true && veggie == false && supreme == false) {
                userPizza.setImageResource(R.drawable.pizza_meat);
                pizzaSelect = 0;
            } else if (veggie == true && meat == false && supreme == false) {
                userPizza.setImageResource(R.drawable.pizza_veggie);
                pizzaSelect = 1;
            } else {
                userPizza.setImageResource(R.drawable.pizza_supreme);
                pizzaSelect = 2;
            }

        }
    }
}
