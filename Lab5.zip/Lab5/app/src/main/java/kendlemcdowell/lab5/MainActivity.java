package kendlemcdowell.lab5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void myAppRunning(View view){
        TextView introRock = findViewById(R.id.textView);
        EditText name = findViewById(R.id.editText3);
        String nameValue = name.getText().toString();
        introRock.setText("This is your pet rock " + nameValue + ".");
        ImageView stone = findViewById(R.id.imageView);
        stone.setImageResource(R.drawable.stone);
    }
}
